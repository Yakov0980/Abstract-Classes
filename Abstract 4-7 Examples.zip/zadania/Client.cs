﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadania
{
    abstract class Client
    {
        public abstract void Print();
        public abstract bool IsClientByDate(DateTime date);
    }

    class Investor : Client
    {
        public string Surname;
        public DateTime DepositDate;
        public string DepositAmount;
        public double DepositInterest;

        public Investor(string surname, DateTime depositDate, string depositAmount, double depositInteres)
        {
            this.Surname = surname;
            this.DepositDate = depositDate;
            this.DepositAmount = depositAmount;
            this.DepositInterest = depositInteres;
        }


        public override void Print()
        {
            Console.WriteLine("Фамилия вкладчика: {0}", Surname);
            Console.WriteLine("Дата открытия вклада: {0}", DepositDate.ToShortDateString());
            Console.WriteLine("Размер вклада: {0}", DepositAmount);
            Console.WriteLine("Процент по вкладу: {0}", DepositInterest);
        }

        public override bool IsClientByDate(DateTime date)
        {
            if (DepositDate == date)
                return true;
            return false;
        }
    }

    class Creditor : Client
    {
        public string Surname;
        public DateTime CreditDate;
        public string CreditAmount;
        public int CreditInterest;
        public string CreditBalance;

        public Creditor(string surname, DateTime creditDate, string creditAmount, int creditInterest,
                        string creditBalance)
        {
            Surname = surname;
            CreditDate = creditDate;
            CreditAmount = creditAmount;
            CreditInterest = creditInterest;
            CreditBalance = creditBalance;
        }

        public override void Print()
        {
            Console.WriteLine("Фамилия вкладчика: {0}", Surname);
            Console.WriteLine("Дата выдачи кредита: {0}", CreditDate.ToShortDateString());
            Console.WriteLine("Размер кредита: {0}", CreditAmount);
            Console.WriteLine("Процент по кредиту: {0}", CreditInterest);
            Console.WriteLine("Остаток долга: {0}", CreditBalance);
        }

        public override bool IsClientByDate(DateTime date)
        {
            if (CreditDate == date)
                return true;
            return false;
        }
    }

    class Organization2 : Client
    {
        public string Name;
        public DateTime AccountDate;
        public int AccountNumber;
        public string AccountAmount;

        public Organization2(string name, DateTime accountDate, int accountNumber, string accountAmount)
        {
            this.Name = name;
            this.AccountDate = accountDate;
            this.AccountNumber = accountNumber;
            this.AccountAmount = accountAmount;
        }

        public override void Print()
        {
            Console.WriteLine("Название организации: {0}", Name);
            Console.WriteLine("Дата открытия счета: {0}", AccountDate.ToShortDateString());
            Console.WriteLine("Номер счета: {0}", AccountNumber);
            Console.WriteLine("Сумма на счету: {0}", AccountAmount);
        }

        public override bool IsClientByDate(DateTime date)
        {
            if (AccountDate == date)
                return true;
            return false;
        }

        private static IEnumerable<Person> FindSurname(Spravka[] spravkaDataBase, string surnameSubstring)
        {
            foreach (var s in spravkaDataBase)
                if (s is Person)
                    if ((s as Person).Surname.Contains(surnameSubstring))
                        yield return s as Person;

        }
    }
}
