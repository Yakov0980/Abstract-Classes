﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Zadania
{
    abstract class PO
    {
        protected string name;
        protected string company;
        protected DateTime dateOfInstall;
        protected byte demo_preiod;
        protected int cost;

        public PO(string name, string company, string date, byte demo_period, int cost)
        {
            this.name = name;
            this.company = company;
            this.dateOfInstall = DateTime.Parse(date);
            this.demo_preiod = demo_period;
            this.cost = cost;
        }
        public virtual void Print()
        {
            Console.WriteLine("\nИмя продукта: " + name + " Производитель: " + company + " дата установки ПО: " + dateOfInstall
                                 + "Период бесплатного использования: " + demo_preiod
                                 + " стоимость продукта: " + cost + "\n");
        }
        public virtual bool ItIsAWorks()
        {
            if (dateOfInstall.AddDays(demo_preiod) >= DateTime.Now) return true;
            return false;
        }
        public string ProgramName
        {
            get { return name; }
        }
    }
    class Free : PO
    {
        public Free(string name, string company) : base(name, company, "01.01.2000", 0, 0)
        { }

        public override void Print()
        {
            Console.WriteLine("Имя продукта: " + name + "\nПроизводитель: "
                                 + company + "\n");
        }
        public override bool ItIsAWorks()
        {
            return true;
        }
    }
    class Shareware : PO
    {
        public Shareware(string name, string company, string date, byte demo_period, int cost)
            : base(name, company, date, demo_period, cost)
        { }

        public override void Print()
        {
            Console.WriteLine("Имя продукта: " + name + "\nПроизводитель: "
                                 + company + "\nДата установки ПО: " + dateOfInstall
                                 + "\nПериод бесплатного использования: " + demo_preiod
                                 + "\nCтоимость продукта: " + cost + "\n");
        }
        public override bool ItIsAWorks()
        {
            if (dateOfInstall.AddDays(demo_preiod) >= DateTime.Now) return true;
            return false;
        }
    }
    class Commercial : PO
    {
        int period;
        public Commercial(string name, string company, string date, byte demo_period, int cost, int period)
            : base(name, company, date, 0, cost)
        { this.period = period; }

        public override void Print()
        {
            Console.WriteLine("Имя продукта: " + name + "\nПроизводитель: "
                                 + company + "\nДата установки ПО: " + dateOfInstall
                                 + "\nСтоимость продукта: " + cost + "\nПериод использования: " + period + "\n");
        }
        public override bool ItIsAWorks()
        {
            if (dateOfInstall.AddDays(period) >= DateTime.Now) return true;
            return false;
        }
    }
}
