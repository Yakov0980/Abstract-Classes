﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadania
{
    abstract class Persona
   
    {
        string surname;
        DateTime birthDay;

        public DateTime BirthDay { get { return birthDay; } set { if (birthDay.Year > 1920 && birthDay.Year < 2000) birthDay = value; }}

        public string Surname { get { return surname; } set { surname = value; }}
        public int Age { get { return DateTime.Now.Year - birthDay.Year; } }
        
        public Persona(string name, DateTime birthDay) { this.surname = name; this.birthDay = birthDay; }

        public abstract void Print();
    }

    class Entrant : Persona
    {
        string faculty;
        int kourse;

        public string Faculty { get { return faculty; } set { if (faculty == "Economist" || faculty == "Painting") faculty = value; }}

        public Entrant(string surname, DateTime birthDay, string faculty, int kourse) : base(surname, birthDay)
        {
            this.faculty = faculty;
            this.kourse = kourse;
        }

        public override void Print()
        {
            Console.WriteLine("Surname: {0}, Age: {1}, Faculty: {2}, Kourse: {3}.", Surname, Age, faculty, kourse);
        }
    }

    class Student : Persona
    {
        string faculty;
        int kourse;

       public string Faculty { get { return faculty; } set { if (faculty == "Economist" || faculty == "Painting") faculty = value; }}

        public int Kourse { get { return kourse; } set { if (kourse > 0 && kourse < 7) kourse = value; }}

        public Student(string surname, DateTime birthDay, string faculty, int kourse) : base(surname, birthDay)
        {
            this.faculty = faculty;
            this.kourse = kourse;
        }

        public override void Print()
        {
            Console.WriteLine("Name: {0}, Age: {1}, Faculty: {2}, Kourse: {3}.", Surname, Age, faculty, kourse);
        }
    }

    class Prepodavatel : Persona
    {
        string faculty;
        string dolchost;
        int staw; 
        public Prepodavatel(string surname, DateTime birthDay, string faculty, string dolchost, int staw) : base(surname, birthDay) 
        {
            this.faculty = faculty;
            this.dolchost = dolchost;
            this.staw = staw; 
        }
        public override void Print()
        {
            Console.WriteLine("Name: {0}, Age: {1}, Faculty: {2}, Post: {3}, Experience: {4}.", Surname, Age, faculty, dolchost, staw);
        }
    }
}
