﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadania
{
     abstract class Spravka
     {
        public abstract void Print();
     }

        class Person : Spravka
        {
        public string Surname;
        public string Adres;
        public string Telephone;
        public Person(string surname, string adres, string telephone)
        {
            this.Surname = surname;
            this.Adres = adres;
            this.Telephone = telephone;
        }

            public override void Print()
            {
                Console.WriteLine("Фамилия: {0}, Адрес: {1}, Телефон: {2}.",Surname,Adres,Telephone);
              
            }
        }

        class Organization : Spravka
        {
        public string Name;
        public string Adres;
        public string Number;
        public int Faks;
        public string Kontakt;
        public Organization(string name, string adres, string number, int faks, string kontakt)
        {
            this.Name = name;
            this.Adres = adres;
            this.Number = number;
            this.Faks = faks;
            this.Kontakt = kontakt;
        }
        public override void Print()
            {
                Console.WriteLine("Название организации: {0},Адрес: {1},Номер телефона: {2},Факс: {3},Контактное лицо: {4}.", Name, Adres, Number, Faks, Kontakt);
            }
        }

        class Friend : Person
        {
        public DateTime BirthdayDate;
        public Friend(string surname, string adres, string telephone, DateTime birthdayDate) : base(surname, adres, telephone)
        {
            this.BirthdayDate = birthdayDate;
        }
        public override void Print()
        {
            Console.WriteLine("Дата рождения: {0}", BirthdayDate);
        }
        
    
        }

}