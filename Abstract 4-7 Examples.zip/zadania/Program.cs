﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadania
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Spisok s = new Spisok();                                                //1 zad. 
            //s.AddEdition(new Book("Book", "LastnameofAutor1", "2018", "Books"));
            //s.AddEdition(new Book("Book", "LastnameofAutor2", "2017", "Books"));
            //s.AddEdition(new Statia("Statia", "LastnameofAutor1", "2010", "Namemagazine2", 10));
            //s.AddEdition(new Statia("Statia", "LastnameofAutor1", "2009", "Namemagazine2", 15));
            //s.AddEdition(new InterntEdition("Intern", "LastnameofAutor2", "//http'что-то'", "Annotation"));
            //foreach (var p in s.list)
            //{
            //    p.GetInfo();
            //}
            //Console.WriteLine("Список с фамилией 'LastnameofAutor2': ");
            //s.FindEdition("LastnameofAutor2");
            //Console.ReadLine();


            //Tran[] a = {new  Motocikl("Lexus", 200, "373AD|02", 200, false),         //2 zad. 
            //                       new Motocikl("Nissan", 160, "373AD|02", 160, true),
            //                       new Legkova("BMW", 210, "375AD|05", 200),
            //                       new Legkova("Suzuki", 140, "378AD|08", 200),
            //                       new Gruzovie("Isuzu", 80, "380AD|02", 500, true),
            //                       new Gruzovie("Infiniti", 180, "385AD|02", 450, false)
            //};

            //for (int i = 0; i < a.Length; i++)
            //    a[i].Print();
            //Console.ReadKey();


            //    List<Persona> persons = new List<Persona>();                                    //3 zad. 
            //    persons.Add(new Student("Oleg", new DateTime(2000, 2, 23), "Economist", 4));
            //    persons.Add(new Entrant("Piter", new DateTime(1995, 5, 25), "Painting", 3));
            //    persons.Add(new Prepodavatel("Olga", new DateTime(1983, 9, 8), "Menegment", "Teacher", 15));

            //    foreach (var p in persons)
            //    {
            //        p.Print();
            //    }
            //    Console.WriteLine("Persona старше 30 лет ");

            //    foreach (Persona p in persons)
            //    {
            //        if (p.Age > 30)
            //            p.Print();
            //    }

            //    Console.ReadLine();

            //} 




            //Spravka[] s = new Spravka[]                        //5 zad. 
            //{
            //    new Person("Смирнов", "Адрес1", "+77054032401"),
            //    new Person("Петров", "Адрес2", "+7708765908"),
            //    new Organization("Организация1", "Адрес3", "+77072344507", 3335545, "Ольга Юрьевна"),
            //    new Organization("Организация2", "Адрес4", "+77053694769", 4577788, "Иван Александрович"),
            //    new Friend("Меретеков", "Адрес5", "+77083452319", new DateTime(1980, 5, 10)),
            //    new Friend("Усинов", "Адрес6", "+87683456523", new DateTime(1985, 9, 8))
            //                                };


            //for (int i = 0; i < s.Length; i++)
            //    s[i].Print();
            //Console.ReadKey();



            // Client[] clientDataBase = new Client[]                         //6 zad.
            // {
            // new Investor("Смирнов", new DateTime(2011,5,7), "250200", 20),
            // new Investor("Петров", new DateTime(2000, 4, 7), "120000", 20),
            // new Creditor("Меретеков", new DateTime(2015, 8, 5), "125000", 20, "12000"),
            // new Creditor("Усинов", new DateTime(2013, 7, 20), "180000", 20, "12000"),
            // new Organization2("Организация1", new DateTime(2009,2,17), 13072, "350000"),
            // new Organization2("Организация2", new DateTime(2014,2,10), 23097, "400000")
            // };

            // foreach (Client client in clientDataBase)
            // {
            //     client.Print();
            // }

            // Console.WriteLine();

            //Console.WriteLine("Клиенты с датой (17.02.2009)");
            // DateTime askDate = new DateTime(2009, 2, 17);
            // int foundClients = 0;

            // foreach (Client client in clientDataBase)
            // {
            //     if (client.IsClientByDate(askDate))
            //     {
            //         client.Print();
            //         foundClients++;
            //         Console.WriteLine();
            //     }
            // }

            // Console.ReadLine();




            //PO[] soft = new PO[]{new Free ("word", "office"),           //7 zad. 
            //                new Shareware("excel", "microsoft", "15.06.1990", 25, 50000),
            //                new Shareware("notepad", "net", "05.04.1990", 50, 200),
            //                new Commercial("NFS most wonted", "EArts", "30.09.2008", 50, 100000, 180),
            //                new Free("paint", "microsoft")};


            //for (int i = 0; i < soft.Length; i++)
            //    soft[i].Print();


            //Console.WriteLine("Список ПО, которое можно использовать на сегодняшний день: ");
            //foreach (PO p in soft)
            //    if (p.ItIsAWorks()) Console.WriteLine(p.ProgramName);

            //Console.ReadLine();






        }

    }
}
 


   





    

    




    

    



    





