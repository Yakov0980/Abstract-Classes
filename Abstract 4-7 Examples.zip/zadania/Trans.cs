﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadania
{
    abstract class Tran
    {
        public string marka;
        public string number;
        public double speed;
        public double liftPower;

        public Tran(string m, string numb, double s, double liftp, bool b = false)
        {
            marka = m;
            number = numb;
            speed = s;
            liftPower = liftp;
        }

        public abstract void Print();
    }
    class Legkova : Tran
    {
        public Legkova(string m, double s, string numb, double liftp) : base(m, numb, s, liftp) { }
        public override void Print()
        {
            Console.WriteLine("Фирма: {0} \nМаксимальная скорость {1} \nНомер: {2} \nГрузоподьемность: {3} ", marka, speed, number, liftPower);
            Console.WriteLine();
        }
    }
    
    class Motocikl : Tran
    {
        public bool kolyaska;
        public Motocikl(string m, double s, string numb, double liftp, bool k) : base(m, numb, s, liftp)
        {
            kolyaska = k;
            if (k == false)
                liftPower = 0;
            else
                liftPower = liftp;
        }
        public override void Print()
        {
            Console.WriteLine("Марка: {0} \nМаксимальная скорость {1} \nНомер: {2} \nГрузоподьемность: {3} \nНаличие коляски: {4}", marka, speed, number, liftPower, kolyaska);
            Console.WriteLine();
        }
    }
    
    class Gruzovie : Tran
    {
        public bool pricep;
        public Gruzovie(string m, double s, string numb, double liftp, bool p) : base(m, numb, s, liftp)
        {
            pricep = p;
            if (pricep == true)
                liftPower *= 2;
        }
        public override void Print()
        {
            Console.WriteLine("Марка: {0} \nМаксимальная скорость {1} \nНомер: {2} \nГрузоподьемность: {3} \nНаличие прицепа: {4}", marka, speed, number, liftPower, pricep);
            Console.WriteLine();
        }
    }

   
}
