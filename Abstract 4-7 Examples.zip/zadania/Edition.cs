﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadania
{
    abstract class Edition
    {
        public string NamePublication;
        public string LastNameAuthor;
        public Edition(string name, string lastname)
        {
            NamePublication = name;
            LastNameAuthor = lastname;
        }
        public abstract void GetInfo();
    }
    class Book : Edition
    {
        public string YearPublication;
        public string NameOfEdition;
        public Book(string name, string lastname, string year, string nameedition) : base(name, lastname)
        {
            YearPublication = year;
            NameOfEdition = name;
        }
        public override void GetInfo()
        {
            Console.WriteLine("Information : {0},{1},{2},{3}", NamePublication, LastNameAuthor, YearPublication, NameOfEdition);
        }
    }
    class Statia : Edition
    {
        public string NameMagazine;
        public int Number;
        public string YearPublicat;
        public Statia(string name, string lastname, string year, string magazine, int number) : base(name, lastname)
        {
            NameMagazine = magazine;
            Number = number;
            YearPublicat = year;
        }
        public override void GetInfo()
        {
            Console.WriteLine("Information:{0},{1},{2},{3},{4}", NamePublication, LastNameAuthor, NameMagazine, Number, YearPublicat);
        }
    }
    class InterntEdition : Edition
    {
        public string Link;
        public string Annotation;
        public InterntEdition(string name, string lastname, string link, string annotation) : base(name, lastname)
        {
            Link = link;
            Annotation = annotation;
        }
        public override void GetInfo()
        {
            Console.WriteLine("Information:{0},{1},{2},{3}", NamePublication, LastNameAuthor, Link, Annotation);
        }
    }
    class Spisok
    {
        public List<Edition> list = new List<Edition>();
        public void AddEdition(Edition ed)
        {
            list.Add(ed);
        }
        public void FindEdition(string lastname)
        {
            foreach (var p in list.FindAll(p => p.LastNameAuthor == lastname))
                p.GetInfo();
        }
    }
}
